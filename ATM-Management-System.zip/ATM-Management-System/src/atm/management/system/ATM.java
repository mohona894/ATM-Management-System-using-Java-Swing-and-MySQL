
package atm.management.system;

/**
 *
 * @author Nasif
 */
public class ATM {
    
}
