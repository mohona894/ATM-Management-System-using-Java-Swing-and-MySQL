
package atm.management.system;

/**
 *
 * @author Nasif
 */
public class ATMManagementSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
